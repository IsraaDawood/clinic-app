
تعليمات إعداد Supabase:

1. أنشئ جدول patients يحتوي:
   - id (PK - auto increment)
   - full_name (text)
   - birth_date (date)
   - age (int)
   - phone (text)
   - notes (text)
   - treatment (text)
   - face_subtype (text)
   - start_date (date)
   - before_image_url (text)
   - created_at (timestamp with time zone - default now())

2. أنشئ جدول sessions يحتوي:
   - id (PK - auto increment)
   - patient_id (bigint - FK إلى patients.id)
   - session_date (date)
   - doctor_notes (text)
   - after_image_url (text)
   - created_at (timestamp - default now())

3. أنشئ bucket باسم: patients-images

4. ضع ملف الخلفية داخل نفس مجلد الملفات

5. لتشغيل الموقع:
   - شغّل أي ملف (مثلاً: index.html) على متصفح حديث
   - يفضل استخدام python -m http.server لتجنب مشاكل رفع الصور
